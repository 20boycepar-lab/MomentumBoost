# Ai Tracer — Local Dev Build (Mock Data, No Keys Needed)

## Quick Start
```bash
npm i -g pnpm
pnpm install
pnpm dev         # open http://localhost:3000
# (optional) in another terminal for BTC/ETH mock ticks:
pnpm --filter @aitracer/web ws:mock
```

This build uses **mock quotes/news/options** and a **local crypto WS mock** so it works completely offline.
Flip to live later by adding real API keys and swapping providers.
