export default function Alerts(){ return <div className='card'>Create alerts in production; local build stores them in memory.</div> }
