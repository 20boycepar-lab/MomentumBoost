import { NextRequest, NextResponse } from 'next/server'
import { mock } from '@aitracer/core'
export async function GET(req: NextRequest) {
  const symbol = req.nextUrl.searchParams.get('symbol') ?? undefined
  const items = await mock.getNews(symbol || undefined)
  return NextResponse.json(items, { headers: { 'Cache-Control': 'no-store' } })
}
