import { NextRequest, NextResponse } from 'next/server'
import { mock } from '@aitracer/core'
export async function GET(req: NextRequest) {
  const symbol = (req.nextUrl.searchParams.get('symbol') || 'AAPL').toUpperCase()
  const chain = await mock.getOptionsChain(symbol)
  return NextResponse.json(chain, { headers: { 'Cache-Control': 'no-store' } })
}
