import { NextRequest, NextResponse } from 'next/server'
import { mock } from '@aitracer/core'
export async function GET(req: NextRequest) {
  const s = req.nextUrl.searchParams.get('s')?.split(',').slice(0,50) ?? []
  const data = await mock.getQuotes(s)
  return NextResponse.json(data, { headers: { 'Cache-Control': 'no-store' } })
}
