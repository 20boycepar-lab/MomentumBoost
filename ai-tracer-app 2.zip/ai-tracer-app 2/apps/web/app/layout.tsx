export const metadata = { title: 'Ai Tracer', description: 'Real-time trading intelligence' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header style={{borderBottom:'1px solid #1f2937', padding:'12px 16px', display:'flex', justifyContent:'space-between'}}>
          <div style={{fontWeight:700}}>Ai Tracer</div>
          <nav style={{display:'flex', gap:12}}>
            <a href="/">Dashboard</a>
            <a href="/watchlist">Watchlist</a>
            <a href="/alerts">Alerts</a>
          </nav>
        </header>
        <main style={{padding:'24px'}}>{children}</main>
      </body>
    </html>
  )
}
