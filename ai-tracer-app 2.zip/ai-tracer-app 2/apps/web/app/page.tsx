import CryptoStrip from '../src/components/CryptoStrip'
import LiveCard from '../src/components/LiveCard'
export default function Page(){
  const symbols = ['AAPL','MSFT','NVDA','SPY','TSLA']
  return (
    <div style={{display:'grid', gap:16}}>
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <h1 style={{fontSize:28, fontWeight:800}}>Ai Tracer — Live Deck</h1>
        <CryptoStrip />
      </div>
      <div style={{display:'grid', gridTemplateColumns:'repeat(5, minmax(0,1fr))', gap:16}}>
        {symbols.map(s => <LiveCard key={s} symbol={s} />)}
      </div>
    </div>
  )
}
