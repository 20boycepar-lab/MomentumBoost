export default function Watchlist(){ return <div className='card'>Watchlist is using mock data locally.</div> }
