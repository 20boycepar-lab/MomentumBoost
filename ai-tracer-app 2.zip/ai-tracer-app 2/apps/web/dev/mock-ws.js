const WebSocket = require('ws')
const port = process.env.WS_PORT || 8787
const wss = new WebSocket.Server({ port })
console.log('Mock WS listening on ws://localhost:' + port)
function tick(sym, base) {
  const drift = (Math.random() - 0.5) * (sym==='BTCUSDT'? 20 : 1)
  base += drift
  return { s: sym, p: Number(base.toFixed(2)), t: Date.now() }
}
wss.on('connection', ws => {
  let btc = 68000, eth = 3500
  const iv = setInterval(() => {
    ws.send(JSON.stringify(tick('BTCUSDT', btc)))
    ws.send(JSON.stringify(tick('ETHUSDT', eth)))
  }, 500)
  ws.on('close', () => clearInterval(iv))
})
