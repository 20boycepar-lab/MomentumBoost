export default { experimental: { typedRoutes: true } };
