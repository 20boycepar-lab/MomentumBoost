'use client'
import { useEffect, useState } from 'react'
export default function CryptoStrip() {
  const [btc, setBtc] = useState<number | null>(null)
  const [eth, setEth] = useState<number | null>(null)
  useEffect(()=>{
    const ws = new WebSocket(process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8787')
    ws.onmessage = (ev)=>{
      try {
        const m = JSON.parse(ev.data)
        if (m.s==='BTCUSDT') setBtc(m.p)
        if (m.s==='ETHUSDT') setEth(m.p)
      } catch {}
    }
    return ()=>ws.close()
  }, [])
  return <div style={{display:'flex', gap:12}}>
    <div className="card">BTC {btc ?? '—'}</div>
    <div className="card">ETH {eth ?? '—'}</div>
  </div>
}
