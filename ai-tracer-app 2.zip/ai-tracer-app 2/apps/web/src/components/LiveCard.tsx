'use client'
import { useEffect, useState } from 'react'
import MiniSparkline from './MiniSparkline'
export default function LiveCard({ symbol }: { symbol: string }) {
  const [price, setPrice] = useState<number | null>(null)
  const [series, setSeries] = useState<number[]>([])
  useEffect(()=>{
    let on = true
    const load = async ()=>{
      const r = await fetch(`/api/quotes?s=${symbol}`, { cache:'no-store' })
      const j = await r.json()
      const p = j?.[symbol]?.price ?? null
      if (!on) return
      setPrice(p)
      setSeries(s => p==null ? s : [...s.slice(-59), p])
    }
    load(); const iv = setInterval(load, 3000)
    return ()=>{ on=false; clearInterval(iv) }
  }, [symbol])
  return (
    <div className="card">
      <div style={{opacity:.7, fontSize:12}}>{symbol}</div>
      <div style={{fontSize:22, fontWeight:700}}>{price ?? '—'}</div>
      <MiniSparkline points={series} />
    </div>
  )
}
