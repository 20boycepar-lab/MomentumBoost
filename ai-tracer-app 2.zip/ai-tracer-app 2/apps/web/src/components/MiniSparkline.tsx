'use client'
import { LineChart, Line, ResponsiveContainer } from 'recharts'
export default function MiniSparkline({ points }: { points: number[] }) {
  const data = points.map((y,i)=>({i,y}))
  return (
    <div style={{ width:'100%', height:60 }}>
      <ResponsiveContainer>
        <LineChart data={data}>
          <Line type="monotone" dataKey="y" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
