import type { QuoteMap } from "../util/types.js";
export async function getQuotes(symbols: string[]): Promise<QuoteMap> {
  const t = Date.now(); const out: QuoteMap = {};
  symbols.forEach((sym, i) => {
    const base = 50 + (sym.codePointAt(0) ?? 65) % 200;
    const noise = (Math.sin(t/10000 + i) + 1) * 2;
    out[sym] = { symbol: sym, price: Number((base + noise).toFixed(2)), ts: t };
  });
  return out;
}
export async function getNews(symbol?: string) {
  return Array.from({length: 8}).map((_,i)=>({ id: `${symbol||'MARKET'}-${i}`, title: `Mock headline ${i+1} for ${symbol||'market'}`, url: "#"}));
}
export async function getOptionsChain(symbol: string) {
  return Array.from({length: 20}).map((_,i)=>({ side: i%2? 'put':'call', strike: 100+i, bid: +(Math.random()*2).toFixed(2), ask: +(Math.random()*2+0.1).toFixed(2), iv: +(0.3+Math.random()*0.4).toFixed(2), delta: +(Math.random()*2-1).toFixed(2) }));
}
