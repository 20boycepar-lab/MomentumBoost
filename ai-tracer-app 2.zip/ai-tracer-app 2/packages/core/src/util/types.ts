export type Quote = { price:number; ts:number; symbol:string }; export type QuoteMap = Record<string, Quote>;
